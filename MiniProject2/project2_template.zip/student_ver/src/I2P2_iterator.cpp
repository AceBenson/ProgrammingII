#include "../header/I2P2_iterator.h"

namespace I2P2 {
  /* Your definition for the iterator class goes here */
}  // namespace I2P2

