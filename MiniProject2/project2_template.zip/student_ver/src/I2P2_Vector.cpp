#include "../header/I2P2_Vector.h"

namespace I2P2 {
  /* Your definition for the Vector class goes here */
}  // namespace I2P2

